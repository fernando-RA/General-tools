/*
  http://stackoverflow.com/a/15435045
  http://stackoverflow.com/a/565282/202451
  http://stackoverflow.com/questions/471962/how-do-determine-if-a-polygon-is-complex-convex-nonconvex
  https://github.com/morris821028/UVa/blob/master/volume004/460%20-%20Overlapping%20Rectangles.c

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "composedTypes.h"
#include "functions.h"

int main(){

  printMenuInicial();

  return 0;
}
