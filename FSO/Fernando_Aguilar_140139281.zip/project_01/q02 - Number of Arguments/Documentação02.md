# Documentação minima da aplicação 02

### ALUNOS
  * Fernando Ribeiro Aguilar - 14/0139281
----

## Calculo do numero de argumentos iniciais

* #### Sistema operacional Utilizado:
  * Debian 8 "Jessie"

* #### Ambiente de desenvolvimento:
  * Editor de Texto: Atom
  * Complilador: gcc
  * Interface Gráfica: Gnome

* #### Telas:
  * Tela inicial e Resultados
    ![Tela inicial](http://i.imgur.com/0BiNigw.png)


* #### Limitações conhecidas:
  * O programa não possui limitações conhecidas
