#ifndef HEADERS
#define HEADERS

#include <stdlib.h>

typedef struct linkedList{
  int size;
  int currentSize;

  int* array;
} List;

#endif
