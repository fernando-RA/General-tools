# Documentação minima da aplicação 01

### ALUNOS
  * Fernando Ribeiro Aguilar - 14/0139281
----

## Ordenamento de inteiros

* #### Sistema operacional Utilizado:
  * Debian 8 Jessie

* #### Ambiente de desenvolvimento:
  * Editor de Texto: Atom
  * Complilador: gcc
  * Interface Gráfica: Gnome

* #### Limitações conhecidas:
  * O programa possui limitação para resgatar os dados das structs de lista
  * O programa possui limitação de memória
  * O programa foi parcialmente implementado
