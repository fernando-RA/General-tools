#ifndef SORTFUNCTIONS
#define SORTFUNCTIONS
#include "headers.h"

int* allocArray();
List readNumbers(List toReturn);
void printList(List toPrint);

#endif
