# Documentação minima - Projeto 02

### ALUNOS
  * Fernando Ribeiro Aguilar - 14/0139281
----

## Comunicação entre processos

* #### Sistema operacional Utilizado:
  * Debian 8 "Jessie"

* #### Ambiente de desenvolvimento:
  * Editor de Texto: Atom
  * Complilador: gcc
  * Interface Gráfica: Gnome

* #### Instruções de Instalação e Execução:
  * Para compilar o projeto:
   `make`
  * Para Executar o projeto:
   `make run`
  * Para limpar os arquivos Binario e Objects (.o)
   `make clean && make remove`

* #### Telas:
  * Tela de Input dos dados:

  * Tela de output das mensagens:

* #### Limitações conhecidas:
  * O programa apresenta 4 casas decimais para mensagens do usuário
  * O programa não informa ao usuário caso esteja encerrando.
