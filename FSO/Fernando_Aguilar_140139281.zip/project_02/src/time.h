#ifndef TIME_FUNCTION_H
#define TIME_FUNCTION_H

  void calcute_time_elapsed(struct timeval *startTime, struct timeval *finishedTime, struct timeval *result);

#endif
