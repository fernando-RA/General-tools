#ifndef __CORE_INCLUDES_H__
#define __CORE_INCLUDES_H__

  #include <stdio.h>
  #include <stdlib.h>
  #include <pthread.h>
  #include <time.h>

  #include "data_utility.h"
  #include "thread_producer_consumer.h"
  #include "controller_thread.h"
  #include <signal.h>

#endif
